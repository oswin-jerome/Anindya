import { jsx, Fragment } from "react/jsx-runtime";
import { G as Guest } from "./GuestLayout-WwhODqS7.js";
import "./ApplicationLogo-DRETeZBQ.js";
import "@inertiajs/react";
function Welcome({
  auth,
  laravelVersion,
  phpVersion
}) {
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsx(Guest, { children: /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("h1", { children: "Hello" }) }) }) });
}
export {
  Welcome as default
};
