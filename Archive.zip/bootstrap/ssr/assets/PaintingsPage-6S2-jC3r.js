import { jsxs, Fragment, jsx } from "react/jsx-runtime";
import { Head, Link } from "@inertiajs/react";
import { S as SiteLayout } from "./SiteLayout-AHuel2zZ.js";
import "react";
function PaintingsPage({
  paintings
}) {
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Head, { title: "Paintings" }),
    /* @__PURE__ */ jsx(SiteLayout, { children: /* @__PURE__ */ jsxs("div", { className: "mt-24 container max-w-[80ch] mx-auto px-4 py-16", children: [
      /* @__PURE__ */ jsx("h3", { className: "text-center mb-4 heading-1", children: "My Paintings" }),
      /* @__PURE__ */ jsx("p", { className: "mx-auto text-center max-w-[500px] description", children: "Step into the world of my artistry and explore the intricate tapestry of emotions and reflections woven into each piece. Connect with me to embark on a journey of introspection and discovery through the lens of art." }),
      /* @__PURE__ */ jsx("section", { className: "mt-20 grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-6 md:gap-8 ", children: paintings.map((painting, i) => {
        return /* @__PURE__ */ jsxs(
          Link,
          {
            href: route(
              "paintings.details",
              painting.slug
            ),
            className: "cursor-pointer",
            children: [
              /* @__PURE__ */ jsx(
                "img",
                {
                  src: painting.painting,
                  alt: " ",
                  className: "rounded w-full aspect-[3/4] object-cover hover:shadow-xl hover:scale-[1.03] transition-all"
                }
              ),
              /* @__PURE__ */ jsx("p", { className: "text-center mt-2 w-[80%] description mx-auto", children: painting.title }),
              /* @__PURE__ */ jsxs("p", { className: "mt-2 text-center description", children: [
                "Rs. ",
                painting.price
              ] })
            ]
          },
          i
        );
      }) })
    ] }) })
  ] });
}
export {
  PaintingsPage as default
};
