import { jsxs, Fragment, jsx } from "react/jsx-runtime";
import { S as SiteLayout } from "./SiteLayout-AHuel2zZ.js";
import { Head, Link } from "@inertiajs/react";
import { CarouselProvider, Slider, Slide, ButtonBack, ButtonNext } from "pure-react-carousel";
import { useState } from "react";
import Modal from "react-modal";
const PaintingDetailsPage = ({
  painting,
  child_paintings
}) => {
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs(Head, { title: "Paintings", children: [
      /* @__PURE__ */ jsx("meta", { name: "title", content: painting.title }),
      /* @__PURE__ */ jsx("meta", { name: "description", content: painting.short_description }),
      /* @__PURE__ */ jsx("meta", { property: "og:type", content: "website" }),
      /* @__PURE__ */ jsx(
        "meta",
        {
          property: "og:url",
          content: "https://anindya.oswinjerome.in/"
        }
      ),
      /* @__PURE__ */ jsx("meta", { property: "og:title", content: painting.title }),
      /* @__PURE__ */ jsx(
        "meta",
        {
          property: "og:description",
          content: painting.short_description
        }
      ),
      /* @__PURE__ */ jsx("meta", { property: "og:image", content: painting.painting }),
      /* @__PURE__ */ jsx("meta", { property: "twitter:card", content: "summary_large_image" }),
      /* @__PURE__ */ jsx(
        "meta",
        {
          property: "twitter:url",
          content: "https://anindya.oswinjerome.in/"
        }
      ),
      /* @__PURE__ */ jsx("meta", { property: "twitter:title", content: painting.title }),
      /* @__PURE__ */ jsx(
        "meta",
        {
          property: "twitter:description",
          content: painting.short_description
        }
      ),
      /* @__PURE__ */ jsx("meta", { property: "twitter:image", content: painting.painting }),
      /* @__PURE__ */ jsx("link", { rel: "preconnect", href: "https://fonts.bunny.net" }),
      /* @__PURE__ */ jsx(
        "link",
        {
          href: "https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap",
          rel: "stylesheet"
        }
      )
    ] }),
    /* @__PURE__ */ jsx(SiteLayout, { children: /* @__PURE__ */ jsxs("div", { className: "mt-24 container mx-auto px-4 py-16 ", children: [
      /* @__PURE__ */ jsxs("section", { className: "grid lg:grid-cols-[3fr,3fr] gap-16", children: [
        /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
          "img",
          {
            className: "w-full h-full",
            src: painting.painting,
            alt: ""
          }
        ) }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs("div", { className: "grid md:grid-cols-[1fr,auto,1fr] gap-4", children: [
            /* @__PURE__ */ jsx("h1", { className: "text-4xl font-bold text-app-primary", children: painting.title }),
            /* @__PURE__ */ jsx("div", { className: "w-full md:w-1 bg-app-primary h-1 md:h-full" }),
            /* @__PURE__ */ jsxs("div", { className: "description", children: [
              /* @__PURE__ */ jsxs("p", { children: [
                "Medium: ",
                painting.medium
              ] }),
              /* @__PURE__ */ jsxs("p", { children: [
                "Size: ",
                painting.size
              ] }),
              /* @__PURE__ */ jsxs("p", { children: [
                "Price: Rs. ",
                painting.price
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "mt-6", children: [
            /* @__PURE__ */ jsx("div", { className: "description leading-loose text-justify prose max-w-full", children: /* @__PURE__ */ jsx(
              "div",
              {
                dangerouslySetInnerHTML: {
                  __html: painting.description
                }
              }
            ) }),
            /* @__PURE__ */ jsx("div", { className: "mt-8 mb-8", children: /* @__PURE__ */ jsx(
              "a",
              {
                href: `https://wa.me/+919800501350?text=I'm interested to buy this painting "${painting.title}"
 ${route(
                  "paintings.details",
                  painting.slug
                )}`,
                className: "bg-transparent border border-app-primary mt-2 z-10 relative text-app-primary  px-8 py-2  active:scale-95 rounded-full",
                children: "Buy Painting"
              }
            ) }),
            child_paintings.length > 0 && /* @__PURE__ */ jsx("h4", { className: "text-xl font-bold", children: "Related Paintings" }),
            child_paintings.length > 0 && /* @__PURE__ */ jsx("div", { className: "gap-4 mt-4 relative ", children: /* @__PURE__ */ jsxs(
              CarouselProvider,
              {
                naturalSlideWidth: 100,
                naturalSlideHeight: 100,
                totalSlides: child_paintings.length,
                visibleSlides: 3,
                infinite: true,
                className: "outline-0",
                children: [
                  /* @__PURE__ */ jsx(Slider, { children: child_paintings.map(
                    (paint, i) => {
                      return /* @__PURE__ */ jsx(
                        Slide,
                        {
                          index: i,
                          className: "",
                          children: /* @__PURE__ */ jsx(
                            PaintItem,
                            {
                              paint
                            }
                          )
                        },
                        i
                      );
                    }
                  ) }),
                  /* @__PURE__ */ jsx(ButtonBack, { className: " hidden md:block absolute md:-left-10 top-[50%] -translate-y-[50%] text-black/50", children: /* @__PURE__ */ jsx(
                    "svg",
                    {
                      xmlns: "http://www.w3.org/2000/svg",
                      fill: "none",
                      viewBox: "0 0 24 24",
                      strokeWidth: 1.5,
                      stroke: "currentColor",
                      className: "w-8 h-8",
                      children: /* @__PURE__ */ jsx(
                        "path",
                        {
                          strokeLinecap: "round",
                          strokeLinejoin: "round",
                          d: "M15.75 19.5 8.25 12l7.5-7.5"
                        }
                      )
                    }
                  ) }),
                  /* @__PURE__ */ jsx(ButtonNext, { className: " hidden md:block absolute  md:-right-10 top-[50%] -translate-y-[50%] text-black/50", children: /* @__PURE__ */ jsx(
                    "svg",
                    {
                      xmlns: "http://www.w3.org/2000/svg",
                      fill: "none",
                      viewBox: "0 0 24 24",
                      strokeWidth: 1.5,
                      stroke: "currentColor",
                      className: "w-8 h-8",
                      children: /* @__PURE__ */ jsx(
                        "path",
                        {
                          strokeLinecap: "round",
                          strokeLinejoin: "round",
                          d: "m8.25 4.5 7.5 7.5-7.5 7.5"
                        }
                      )
                    }
                  ) })
                ]
              }
            ) })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsx("section", { className: "mt-20 description leading-loose text-justify prose max-w-full", children: /* @__PURE__ */ jsx(
        "div",
        {
          dangerouslySetInnerHTML: {
            __html: painting.post
          }
        }
      ) })
    ] }) })
  ] });
};
function PaintItem({ paint }) {
  const [modalIsOpen, setIsOpen] = useState(false);
  const customStyles = {
    content: {
      top: "50%",
      left: "50%",
      right: "auto",
      bottom: "auto",
      marginRight: "-50%",
      transform: "translate(-50%, -50%)"
    }
  };
  return /* @__PURE__ */ jsxs("div", { className: "p-2 cursor-pointer ", children: [
    /* @__PURE__ */ jsx(
      Modal,
      {
        isOpen: modalIsOpen,
        style: customStyles,
        onRequestClose: () => setIsOpen(false),
        contentLabel: "Example Modal",
        shouldCloseOnOverlayClick: true,
        overlayClassName: "Overlay",
        children: /* @__PURE__ */ jsxs("div", { className: "max-h-[90vh] max-w-[90vw] lg:max-w-[70vw] overflow-scroll pb-16", children: [
          /* @__PURE__ */ jsx("div", { className: "flex justify-end pb-2", children: /* @__PURE__ */ jsx("button", { onClick: () => setIsOpen(false), children: /* @__PURE__ */ jsx(
            "svg",
            {
              xmlns: "http://www.w3.org/2000/svg",
              fill: "none",
              viewBox: "0 0 24 24",
              strokeWidth: 1.5,
              stroke: "currentColor",
              className: "w-6 h-6",
              children: /* @__PURE__ */ jsx(
                "path",
                {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  d: "M6 18 18 6M6 6l12 12"
                }
              )
            }
          ) }) }),
          /* @__PURE__ */ jsxs("div", { className: "grid lg:grid-cols-2 gap-8", children: [
            /* @__PURE__ */ jsx("img", { src: paint.painting, alt: "" }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs("div", { className: "grid md:grid-cols-[1fr,auto,1fr] gap-4", children: [
                /* @__PURE__ */ jsx("h1", { className: "text-4xl font-bold text-app-primary", children: paint.title }),
                /* @__PURE__ */ jsx("div", { className: "w-full md:w-1 bg-app-primary h-1 md:h-full" }),
                /* @__PURE__ */ jsxs("div", { className: "description", children: [
                  /* @__PURE__ */ jsxs("p", { children: [
                    "Medium: ",
                    paint.medium
                  ] }),
                  /* @__PURE__ */ jsxs("p", { children: [
                    "Size: ",
                    paint.size
                  ] }),
                  /* @__PURE__ */ jsxs("p", { children: [
                    "Price: Rs. ",
                    paint.price
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsx("p", { className: "description mt-6", children: /* @__PURE__ */ jsx(
                "div",
                {
                  dangerouslySetInnerHTML: {
                    __html: paint.description
                  }
                }
              ) }),
              /* @__PURE__ */ jsx("div", { className: "mt-10", children: /* @__PURE__ */ jsx(
                Link,
                {
                  href: route(
                    "paintings.details",
                    paint.slug
                  ),
                  className: "bg-transparent border border-app-primary mt-2 z-10 relative text-app-primary  px-8 py-2  active:scale-95 rounded-full",
                  children: "View"
                }
              ) })
            ] })
          ] })
        ] })
      }
    ),
    /* @__PURE__ */ jsx(
      "img",
      {
        onClick: () => setIsOpen(true),
        src: paint.painting,
        alt: "",
        className: "aspect-square "
      }
    )
  ] });
}
export {
  PaintingDetailsPage as default
};
