import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { Link, Head } from "@inertiajs/react";
import { S as SiteLayout } from "./SiteLayout-AHuel2zZ.js";
import { Carousel } from "react-responsive-carousel";
import "react";
const PaintingAutoGrid = ({ paintings }) => {
  const splitList = (oa) => {
    let res = {
      1: [],
      2: [],
      3: [],
      4: []
    };
    let i = 1;
    oa.forEach((e) => {
      res[i].push(e);
      i = i + 1;
      if (i > 4) {
        i = 1;
      }
    });
    return res;
  };
  const paintGrid = splitList(paintings);
  return /* @__PURE__ */ jsxs("section", { className: "container mx-auto px-4 py-16", children: [
    /* @__PURE__ */ jsx("h3", { className: "text-center  mb-4 heading-1", children: "My Paintings" }),
    /* @__PURE__ */ jsx("p", { className: "mx-auto text-center max-w-[500px] description", children: "Step into the world of my artistry and explore the intricate tapestry of emotions and reflections woven into each piece. Connect with me to embark on a journey of introspection and discovery through the lens of art." }),
    /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 mt-12 lg:mt-20 max-w-[80ch] mx-auto", children: [1, 2, 3, 4].map((k) => {
      return /* @__PURE__ */ jsx("div", { className: "flex flex-col gap-4", children: paintGrid[k].map((painting, i) => {
        return /* @__PURE__ */ jsx(
          Link,
          {
            href: route(
              "paintings.details",
              painting.slug
            ),
            className: "cursor-pointer shadow",
            children: /* @__PURE__ */ jsx(
              "img",
              {
                src: painting.painting,
                alt: " ",
                className: "rounded w-full  object-cover hover:shadow-xl hover:scale-[1.03] transition-all"
              }
            )
          },
          i
        );
      }) }, k);
    }) }),
    /* @__PURE__ */ jsx("div", { className: "flex justify-center", children: /* @__PURE__ */ jsx(
      Link,
      {
        href: route("paintings.page"),
        className: "bg-transparent border border-app-primary z-10 relative text-app-primary mt-16 px-8 py-3  active:scale-95 rounded-full",
        children: "View More"
      }
    ) })
  ] });
};
const PaintingAutoGrid$1 = PaintingAutoGrid;
function LandingPage({ paintings }) {
  const fadeAnimationHandler = (props, state) => {
    const transitionTime = props.transitionTime + "ms";
    const transitionTimingFunction = "ease-in-out";
    let slideStyle = {
      position: "absolute",
      display: "block",
      zIndex: 0,
      minHeight: "100%",
      opacity: 0,
      top: 0,
      right: 0,
      left: 0,
      scale: 1,
      bottom: 0,
      transition: "all",
      transitionTimingFunction,
      msTransitionTimingFunction: transitionTimingFunction,
      MozTransitionTimingFunction: transitionTimingFunction,
      WebkitTransitionTimingFunction: transitionTimingFunction,
      OTransitionTimingFunction: transitionTimingFunction
    };
    if (!state.swiping) {
      slideStyle = {
        ...slideStyle,
        scale: 1.5,
        WebkitTransitionDuration: transitionTime,
        MozTransitionDuration: transitionTime,
        OTransitionDuration: transitionTime,
        transitionDuration: transitionTime,
        msTransitionDuration: transitionTime
      };
    }
    return {
      slideStyle,
      selectedStyle: {
        ...slideStyle,
        opacity: 1,
        scale: 1.5,
        position: "relative"
      },
      prevStyle: { ...slideStyle }
    };
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs(Head, { title: "Home", children: [
      /* @__PURE__ */ jsx("meta", { name: "title", content: "Anindya Mukherjee" }),
      /* @__PURE__ */ jsx(
        "meta",
        {
          name: "description",
          content: "My art is a celebration of the unique interplay between colors, textures, and forms, reflecting my personal interpretation of the world. Each painting is a canvas where I pour my heart and soul, creating visual narratives that resonate with both the subtle and profound aspects of existence."
        }
      ),
      /* @__PURE__ */ jsx("meta", { property: "og:type", content: "website" }),
      /* @__PURE__ */ jsx(
        "meta",
        {
          property: "og:url",
          content: "https://anindya.oswinjerome.in/"
        }
      ),
      /* @__PURE__ */ jsx("meta", { property: "og:title", content: "Anindya Mukherjee" }),
      /* @__PURE__ */ jsx(
        "meta",
        {
          property: "og:description",
          content: "My art is a celebration of the unique interplay between colors, textures, and forms, reflecting my personal interpretation of the world. Each painting is a canvas where I pour my heart and soul, creating visual narratives that resonate with both the subtle and profound aspects of existence."
        }
      ),
      /* @__PURE__ */ jsx(
        "meta",
        {
          property: "og:image",
          content: "https://anindya.oswinjerome.in/images/artist2.jpeg"
        }
      ),
      /* @__PURE__ */ jsx("meta", { property: "twitter:card", content: "summary_large_image" }),
      /* @__PURE__ */ jsx(
        "meta",
        {
          property: "twitter:url",
          content: "https://anindya.oswinjerome.in/"
        }
      ),
      /* @__PURE__ */ jsx("meta", { property: "twitter:title", content: "Anindya Mukherjee" }),
      /* @__PURE__ */ jsx(
        "meta",
        {
          property: "twitter:description",
          content: "My art is a celebration of the unique interplay between colors, textures, and forms, reflecting my personal interpretation of the world. Each painting is a canvas where I pour my heart and soul, creating visual narratives that resonate with both the subtle and profound aspects of existence."
        }
      ),
      /* @__PURE__ */ jsx(
        "meta",
        {
          property: "twitter:image",
          content: "https://anindya.oswinjerome.in/images/artist2.jpeg"
        }
      ),
      /* @__PURE__ */ jsx("link", { rel: "preconnect", href: "https://fonts.bunny.net" }),
      /* @__PURE__ */ jsx(
        "link",
        {
          href: "https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap",
          rel: "stylesheet"
        }
      )
    ] }),
    /* @__PURE__ */ jsxs(SiteLayout, { children: [
      /* @__PURE__ */ jsxs("section", { className: " h-[50vh] md:h-[100vh] relative mt-16 md:mt-auto", children: [
        /* @__PURE__ */ jsxs(
          Carousel,
          {
            centerMode: false,
            showThumbs: false,
            autoPlay: true,
            transitionTime: 1300,
            className: " h-[50vh] md:h-[100vh] relative ",
            animationHandler: fadeAnimationHandler,
            children: [
              /* @__PURE__ */ jsx(
                "img",
                {
                  src: "/images/hero.jpg",
                  className: "object-cover h-[50vh] md:h-[100vh] w-full",
                  alt: ""
                }
              ),
              /* @__PURE__ */ jsx(
                "img",
                {
                  src: "/images/artist.jpg",
                  className: "object-cover h-[50vh] md:h-[100vh] w-full",
                  alt: ""
                }
              ),
              /* @__PURE__ */ jsx(
                "img",
                {
                  src: "/images/artist2.jpeg",
                  className: "object-cover h-[50vh] md:h-[100vh] w-full",
                  alt: ""
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ jsx("div", { className: "bg-black/50 0 absolute inset-0 grid place-items-center p-3", children: /* @__PURE__ */ jsx("h1", { className: "text-3xl md:text-[4em] xl:text-[5em] text-white/90 text-center name capitalize tracking-widest", children: "ANINDYA MUKHERJEE" }) })
      ] }),
      /* @__PURE__ */ jsxs("section", { className: "container mx-auto px-4 py-16", children: [
        /* @__PURE__ */ jsx("h3", { className: "text-center mb-8 md:mb-10 heading-1", children: "About" }),
        /* @__PURE__ */ jsx("div", { className: "", children: /* @__PURE__ */ jsxs("div", { className: "flex-1 text-slate-600 max-w-[80ch] leading-loose text-justify  mx-auto font-content", children: [
          /* @__PURE__ */ jsxs("p", { children: [
            "Welcome to my world of artistry! I'm Anindya Mukherjee, a passionate artist hailing from the picturesque landscapes of India. My art revolves around the profound cycles of life and death, delving into the intricate relationship between humanity and nature.",
            /* @__PURE__ */ jsx("br", {}),
            /* @__PURE__ */ jsx("br", {}),
            "My journey into the realm of art began amidst the serene surroundings of Kurseong hill station, where I spent my childhood . Surrounded by nature's boundless beauty, I found my muse and embarked on a creative exploration that continues to shape my existence. Despite facing economic hurdles and initial rejections from art colleges, my determination fueled my pursuit of artistic expression. Battling periods of depression and frustration, I found solace and inspiration in the ever-evolving canvas of nature. Tragically, the loss of my mother served as a poignant reminder of life's transient nature, igniting a profound introspection into the essence of existence."
          ] }),
          /* @__PURE__ */ jsx("div", { className: "flex justify-center", children: /* @__PURE__ */ jsx(
            Link,
            {
              href: route("about"),
              className: "bg-transparent border border-app-primary z-10 relative text-app-primary mt-16 px-8 py-3  active:scale-95 rounded-full",
              children: "Know More"
            }
          ) })
        ] }) })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "bg-white", children: /* @__PURE__ */ jsx(PaintingAutoGrid$1, { paintings }) })
    ] })
  ] });
}
export {
  LandingPage as default
};
