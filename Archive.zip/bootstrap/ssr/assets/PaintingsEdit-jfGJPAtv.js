import { jsxs, jsx } from "react/jsx-runtime";
import { A as Authenticated } from "./AuthenticatedLayout-24llbqbg.js";
import { useForm, Head, router } from "@inertiajs/react";
import { P as PrimaryButton } from "./PrimaryButton-tCuq_nFx.js";
import ReactQuill from "react-quill";
/* empty css                    */
import "react";
import "./ApplicationLogo-DRETeZBQ.js";
import "@headlessui/react";
function PaintingsEdit({
  auth,
  painting,
  paintings
}) {
  const { data, setData, post, patch, reset, isDirty } = useForm({
    description: painting.description,
    post: painting.post,
    price: painting.price,
    short_description: painting.short_description,
    title: painting.title,
    painting: void 0,
    _method: "put",
    painting_id: painting.painting_id,
    medium: painting.medium,
    size: painting.size
  });
  const handle = (e) => {
    e.preventDefault();
    console.log(data);
    post(route("paintings.update", painting.id), {
      onError: (e2) => {
        console.log(e2);
      },
      onSuccess: (e2) => {
        alert("added");
        reset();
        router.visit(route("paintings.edit", painting.id));
      }
    });
  };
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      user: auth.user,
      header: /* @__PURE__ */ jsx("h2", { className: "font-semibold text-xl text-gray-800 leading-tight", children: "Edit Paintings" }),
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Paintings" }),
        /* @__PURE__ */ jsx("div", { className: "py-12", children: /* @__PURE__ */ jsx("div", { className: "max-w-7xl mx-auto sm:px-6 lg:px-8", children: /* @__PURE__ */ jsx("div", { className: "bg-white overflow-hidden shadow-sm sm:rounded-lg", children: /* @__PURE__ */ jsx("div", { className: "p-6 text-gray-900", children: /* @__PURE__ */ jsxs("form", { onSubmit: handle, className: "grid gap-4", children: [
          /* @__PURE__ */ jsxs("div", { className: "input-box", children: [
            /* @__PURE__ */ jsx("label", { htmlFor: "", children: "Parent Painting" }),
            /* @__PURE__ */ jsxs(
              "select",
              {
                value: data.painting_id,
                onChange: (e) => setData(
                  "painting_id",
                  e.target.value
                ),
                name: "",
                id: "",
                children: [
                  /* @__PURE__ */ jsx("option", { value: "", children: "None" }),
                  paintings.map((paint) => {
                    return /* @__PURE__ */ jsx("option", { value: paint.id, children: /* @__PURE__ */ jsxs("span", { children: [
                      " ",
                      paint.title,
                      " "
                    ] }) });
                  })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "input-box", children: [
            /* @__PURE__ */ jsx("label", { htmlFor: "", children: "Painting" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                onChange: (e) => {
                  var _a;
                  return setData(
                    "painting",
                    (_a = e.target.files) == null ? void 0 : _a[0]
                  );
                },
                type: "file"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "input-box", children: [
            /* @__PURE__ */ jsx("label", { htmlFor: "", children: "Medium" }),
            /* @__PURE__ */ jsxs(
              "select",
              {
                value: data.medium,
                onChange: (e) => setData("medium", e.target.value),
                name: "",
                id: "",
                children: [
                  /* @__PURE__ */ jsx("option", { value: "Charcoal", children: "Charcoal" }),
                  /* @__PURE__ */ jsx("option", { value: "Paint", children: "Paint" }),
                  /* @__PURE__ */ jsx("option", { value: "Pen", children: "Pen" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "input-box", children: [
            /* @__PURE__ */ jsx("label", { htmlFor: "", children: "Size" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                value: data.size,
                onChange: (e) => setData("size", e.target.value),
                type: "text"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "input-box", children: [
            /* @__PURE__ */ jsx("label", { htmlFor: "", children: "Title" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                value: data.title,
                onChange: (e) => setData("title", e.target.value),
                type: "text"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "input-box", children: [
            /* @__PURE__ */ jsx("label", { htmlFor: "", children: "Short Description" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                value: data.short_description,
                onChange: (e) => setData(
                  "short_description",
                  e.target.value
                ),
                type: "text"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "input-box", children: [
            /* @__PURE__ */ jsx("label", { htmlFor: "", children: "Description" }),
            /* @__PURE__ */ jsx(
              ReactQuill,
              {
                theme: "snow",
                className: "block mb-12",
                value: data.description,
                onChange: (e) => setData("description", e)
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "input-box", children: [
            /* @__PURE__ */ jsx("label", { htmlFor: "", children: "Post" }),
            /* @__PURE__ */ jsx(
              ReactQuill,
              {
                theme: "snow",
                className: "block mb-12",
                value: data.post,
                onChange: (e) => setData("post", e)
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "input-box", children: [
            /* @__PURE__ */ jsx("label", { htmlFor: "", children: "Price" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                value: data.price,
                onChange: (e) => setData(
                  "price",
                  e.target.valueAsNumber
                ),
                type: "number"
              }
            )
          ] }),
          /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(PrimaryButton, { disabled: !isDirty, children: "Add" }) })
        ] }) }) }) }) })
      ]
    }
  );
}
export {
  PaintingsEdit as default
};
