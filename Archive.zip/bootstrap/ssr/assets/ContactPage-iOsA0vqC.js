import { jsxs, Fragment, jsx } from "react/jsx-runtime";
import { useForm, Head } from "@inertiajs/react";
import { S as SiteLayout } from "./SiteLayout-AHuel2zZ.js";
import { IoMailOutline, IoLogoWhatsapp } from "react-icons/io5";
import { useState } from "react";
function ContactPage() {
  useState({
    name: "",
    email: "",
    phone: "",
    message: ""
  });
  const { data, setData, post, reset, processing } = useForm({
    name: "",
    email: "",
    phone: "",
    message: ""
  });
  const [status, setStatus] = useState(false);
  const handleSubmit = (e) => {
    e.preventDefault();
    post(route("contact.post"), {
      preserveScroll: true,
      onSuccess: () => {
        reset();
        setStatus(true);
        setTimeout(() => {
          setStatus(false);
        }, 3e3);
      }
    });
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Head, { title: "Contact" }),
    /* @__PURE__ */ jsx(SiteLayout, { children: /* @__PURE__ */ jsxs("section", { className: "container xl:max-w-[80vw] mx-auto px-4 py-16 mt-24", children: [
      /* @__PURE__ */ jsx("h3", { className: "text-center mb-10 md:mb-4 heading-1", children: "Send Us your queries." }),
      /* @__PURE__ */ jsx("p", { className: "mx-auto text-center max-w-[500px] description", children: "Lorem ipsum dolor sit amet consectetur. Eget blandit gravida purus pharetra. Dis praesent volutpat inter" }),
      /* @__PURE__ */ jsxs("section", { className: "mt-12 grid md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2 2xl:grid-cols-2 gap-6 md:gap-8 ", children: [
        /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, className: "h-[100%]", children: [
          status && /* @__PURE__ */ jsx("p", { className: "bg-green-200 p-4 mb-6 rounded text-green-900", children: "Message Sent" }),
          /* @__PURE__ */ jsxs("div", { className: "grid gap-4 h-[100%]", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex flex-1 flex-col gap-2", children: [
              /* @__PURE__ */ jsx("label", { htmlFor: "name", children: "Name" }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  value: data.name,
                  onChange: (e) => (
                    // setFromData({
                    //     ...fromData,
                    //     name: e.target.value,
                    // })
                    setData("name", e.target.value)
                  ),
                  autoComplete: "off",
                  className: "input",
                  id: "name",
                  type: "text",
                  required: true
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row gap-4", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex flex-1 flex-col gap-2", children: [
                /* @__PURE__ */ jsx("label", { htmlFor: "email", children: "Email" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    value: data.email,
                    onChange: (e) => (
                      // setFromData({
                      //     ...fromData,
                      //     email: e.target.value,
                      // })
                      setData("email", e.target.value)
                    ),
                    className: "input ",
                    autoComplete: "off",
                    id: "email",
                    type: "text"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex flex-1 flex-col gap-2", children: [
                /* @__PURE__ */ jsx("label", { htmlFor: "phone", children: "Phone" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    value: data.phone,
                    onChange: (e) => setData("phone", e.target.value),
                    required: true,
                    className: "input",
                    autoComplete: "off",
                    id: "phone",
                    type: "text"
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex flex-1 flex-col gap-2", children: [
              /* @__PURE__ */ jsx("label", { htmlFor: "message", children: "Message" }),
              /* @__PURE__ */ jsx(
                "textarea",
                {
                  value: data.message,
                  onChange: (e) => (
                    // setFromData({
                    //     ...fromData,
                    //     message: e.target.value,
                    // })
                    setData("message", e.target.value)
                  ),
                  rows: 5,
                  id: "message",
                  autoComplete: "off",
                  className: "input"
                }
              )
            ] }),
            /* @__PURE__ */ jsx("div", { className: "flex justify-start items-center ", children: /* @__PURE__ */ jsx(
              "button",
              {
                disabled: processing,
                className: "bg-transparent border border-app-primary mt-2 z-10 relative text-app-primary  px-8 py-2  active:scale-95 rounded-full disabled:opacity-50 inline-block",
                children: processing ? "Sending..." : "Sent"
              }
            ) })
          ] })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "flex justify-center items-start mt-10", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center gap-4", children: [
          /* @__PURE__ */ jsxs("span", { className: "flex gap-3  text-md items-center", children: [
            /* @__PURE__ */ jsx(IoMailOutline, {}),
            /* @__PURE__ */ jsx("a", { href: "mailto:anindyaartist17@gmail.com", children: "anindyaartist17@gmail.com" })
          ] }),
          /* @__PURE__ */ jsxs("span", { className: "flex gap-3 text-md items-center", children: [
            /* @__PURE__ */ jsx(IoLogoWhatsapp, {}),
            /* @__PURE__ */ jsx("a", { href: "tel:+919800501350", children: "+91 98005 01350" })
          ] }),
          /* @__PURE__ */ jsx(
            "a",
            {
              href: "https://wa.me/+919800501350",
              className: " xl:mt-5 px-4 py-2 text-white text-sm rounded-sm bg-green-600",
              children: "Connect via Whatsapp"
            }
          )
        ] }) })
      ] }),
      /* @__PURE__ */ jsxs("section", { className: "container mt-16", children: [
        /* @__PURE__ */ jsx("h3", { className: "text-center mb-10 heading-1", children: "FAQ" }),
        /* @__PURE__ */ jsxs("div", { className: "xl:mt-16 grid md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2 2xl:grid-cols-2 gap-6 md:gap-8", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-12", children: [
            /* @__PURE__ */ jsx("div", { className: "flex flex-1 flex-col gap-2", children: /* @__PURE__ */ jsxs("p", { className: "mx-auto max-w-[500px] description", children: [
              /* @__PURE__ */ jsx("p", { className: "text-app-primary font-semibold mb-2", children: "How do I purchase an original painting?" }),
              "To inquire about purchasing an original painting, sign up for our email list and contact me via WhatsApp. This way, you'll stay updated on available works and can reach out directly to discuss purchasing options."
            ] }) }),
            /* @__PURE__ */ jsx("div", { className: "flex flex-1 flex-col gap-2", children: /* @__PURE__ */ jsxs("p", { className: "mx-auto max-w-[500px] description", children: [
              /* @__PURE__ */ jsx("p", { className: "text-app-primary font-semibold mb-2", children: "Can I commission a painting?" }),
              "If your request aligns with the themes and style of my artwork, I ll be happy to work on commission paintings . Feel free to reach out to discuss further."
            ] }) }),
            /* @__PURE__ */ jsx("div", { className: "flex flex-1 flex-col gap-2", children: /* @__PURE__ */ jsxs("p", { className: "mx-auto max-w-[500px] description", children: [
              /* @__PURE__ */ jsx("p", { className: "text-app-primary font-semibold mb-2", children: "Do you ship worldwide?" }),
              "Absolutely! We ship our artwork to locations across the globe. However, please be aware that additional import taxes may apply depending on your area's customs guidelines and delivery regulations."
            ] }) })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-12", children: [
            /* @__PURE__ */ jsx("div", { className: "flex flex-1 flex-col gap-2", children: /* @__PURE__ */ jsxs("p", { className: "mx-auto max-w-[500px] description", children: [
              /* @__PURE__ */ jsx("p", { className: "text-app-primary font-semibold mb-2", children: "How long does it take to receive a painting?" }),
              "The time-frame for receiving an original painting may vary. Generally, there is an additional processing and delivery time for original artworks. For commissioned pieces , the duration will depend on factors such as size and complexity. Rest assured, we'll work diligently to provide you with a realistic estimate and keep you informed throughout the process."
            ] }) }),
            /* @__PURE__ */ jsx("div", { className: "flex flex-1 flex-col gap-2", children: /* @__PURE__ */ jsxs("p", { className: "mx-auto max-w-[500px] description", children: [
              /* @__PURE__ */ jsx("p", { className: "text-app-primary font-semibold mb-2", children: "Do you accept visitors at your studio?" }),
              "Absolutely! I welcome visitors to my studio with open arms. Whether you're an aspiring artist eager to learn or simply interested in exploring my artwork, feel free to get in touch with me to schedule a visit. I look forward to sharing my creative space with you!"
            ] }) })
          ] })
        ] })
      ] })
    ] }) })
  ] });
}
export {
  ContactPage as default
};
